package com.example

import com.example.core.model.PersonalityMode
import com.example.core.personality.SeenuPersonaEngine
import com.example.core.registry.ModuleStatus
import com.example.core.registry.SeenuModuleRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SeenuCoreUnitTest {

    @Test
    fun testSeenuPersonaPromptGeneration() {
        val prompt = SeenuPersonaEngine.getSystemPrompt(PersonalityMode.SASSY)
        assertTrue(prompt.contains("Seenu"))
        assertTrue(prompt.contains("sassy"))
    }

    @Test
    fun testSeenuModuleRegistryInitialization() {
        val registry = SeenuModuleRegistry()
        val modules = registry.modules.value
        assertEquals("Must contain all 30 modules", 30, modules.size)

        val activeCount = modules.count { it.status == ModuleStatus.ACTIVE }
        assertTrue("Stage 1 must have active core modules", activeCount >= 4)

        val module1 = registry.getModule(1)
        assertNotNull(module1)
        assertEquals("AI Brain & Intent Router", module1?.name)
    }

    @Test
    fun testModuleToggle() {
        val registry = SeenuModuleRegistry()
        val originalStatus = registry.getModule(1)?.status
        assertEquals(ModuleStatus.ACTIVE, originalStatus)

        registry.toggleModule(1)
        assertEquals(ModuleStatus.DISABLED, registry.getModule(1)?.status)

        registry.toggleModule(1)
        assertEquals(ModuleStatus.ACTIVE, registry.getModule(1)?.status)
    }
}
