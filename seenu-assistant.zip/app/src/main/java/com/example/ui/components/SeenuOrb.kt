package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.core.model.AssistantState
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SeenuOrb(
    state: AssistantState,
    modifier: Modifier = Modifier,
    sizeDp: Dp = 210.dp,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_anim")

    // Slow breathing rotation and glow
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AssistantState.THINKING -> 2000
                    AssistantState.SPEAKING -> 3500
                    AssistantState.LISTENING -> 4000
                    AssistantState.ERROR -> 8000
                    AssistantState.IDLE -> 9000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Breathing scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = when (state) {
            AssistantState.LISTENING -> 1.12f
            AssistantState.SPEAKING -> 1.08f
            AssistantState.THINKING -> 1.05f
            AssistantState.ERROR -> 0.98f
            AssistantState.IDLE -> 1.02f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AssistantState.LISTENING -> 600
                    AssistantState.SPEAKING -> 750
                    AssistantState.THINKING -> 500
                    AssistantState.ERROR -> 1200
                    AssistantState.IDLE -> 2400
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // Dynamic wave amplitude for speaking / listening
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    val coreColors = when (state) {
        AssistantState.IDLE -> listOf(NeonCyan, NeonPurple, NeonPink)
        AssistantState.LISTENING -> listOf(NeonCyan, Color(0xFF38BDF8), NeonPurple)
        AssistantState.THINKING -> listOf(NeonPurple, NeonPink, NeonAmber)
        AssistantState.SPEAKING -> listOf(NeonPink, NeonPurple, NeonCyan)
        AssistantState.ERROR -> listOf(NeonRed, NeonAmber, NeonPurple)
    }

    Box(
        modifier = modifier
            .size(sizeDp)
            .testTag("seenu_orb_button")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = sizeDp / 2),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(sizeDp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 2.6f) * pulseScale

            // 1. Outer Diffuse Aura Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColors[0].copy(alpha = 0.35f),
                        coreColors[1].copy(alpha = 0.15f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.55f
                ),
                radius = baseRadius * 1.55f,
                center = center
            )

            // 2. Cyber Orbiting Particle Rings
            val ringCount = 3
            for (r in 0 until ringCount) {
                val ringRadius = baseRadius * (1.15f + r * 0.14f)
                val ringAlpha = if (state == AssistantState.THINKING) 0.5f else 0.25f
                drawCircle(
                    color = coreColors[r % coreColors.size].copy(alpha = ringAlpha),
                    radius = ringRadius,
                    center = center,
                    style = Stroke(width = 1.8f)
                )

                // Orbiting node points
                val angleRad = Math.toRadians((rotation * (r + 1) * 0.7f + r * 120.0).toDouble())
                val nodeOffset = Offset(
                    x = center.x + ringRadius * cos(angleRad).toFloat(),
                    y = center.y + ringRadius * sin(angleRad).toFloat()
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.5f,
                    center = nodeOffset
                )
            }

            // 3. Central Glowing Core Sphere
            drawCircle(
                brush = Brush.linearGradient(
                    colors = coreColors,
                    start = Offset(center.x - baseRadius, center.y - baseRadius),
                    end = Offset(center.x + baseRadius, center.y + baseRadius)
                ),
                radius = baseRadius,
                center = center
            )

            // 4. State-driven Waveforms & Accents
            when (state) {
                AssistantState.SPEAKING, AssistantState.LISTENING -> {
                    // Oscillating Soundwave across center
                    val wavePath = Path()
                    val wavePoints = 24
                    val startX = center.x - baseRadius * 0.75f
                    val endX = center.x + baseRadius * 0.75f
                    val waveWidth = endX - startX

                    for (i in 0..wavePoints) {
                        val frac = i.toFloat() / wavePoints
                        val x = startX + frac * waveWidth
                        val envelope = sin(frac * Math.PI).toFloat() // Damp at edges
                        val amp = (if (state == AssistantState.SPEAKING) 22f else 15f) * envelope
                        val y = center.y + amp * sin(wavePhase + frac * 4 * Math.PI).toFloat()

                        if (i == 0) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
                    }

                    drawPath(
                        path = wavePath,
                        color = Color.White,
                        style = Stroke(width = 3.2f, cap = StrokeCap.Round)
                    )
                }

                AssistantState.THINKING -> {
                    // Concentric fast rotating neon arcs
                    drawArc(
                        brush = Brush.sweepGradient(coreColors, center),
                        startAngle = rotation * 2f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = Offset(center.x - baseRadius * 0.85f, center.y - baseRadius * 0.85f),
                        size = androidx.compose.ui.geometry.Size(baseRadius * 1.7f, baseRadius * 1.7f),
                        style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                    )
                }

                AssistantState.IDLE, AssistantState.ERROR -> {
                    // Subtle central diamond sparkle
                    val sparkleSize = baseRadius * 0.25f
                    val sparkleColor = if (state == AssistantState.ERROR) NeonAmber else Color.White
                    val path = Path().apply {
                        moveTo(center.x, center.y - sparkleSize)
                        lineTo(center.x + sparkleSize * 0.4f, center.y)
                        lineTo(center.x, center.y + sparkleSize)
                        lineTo(center.x - sparkleSize * 0.4f, center.y)
                        close()
                    }
                    drawPath(path = path, color = sparkleColor.copy(alpha = 0.85f))
                }
            }
        }
    }
}
