package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.AssistantState
import com.example.ui.components.PermissionsOnboardingCard
import com.example.ui.components.SeenuOrb
import com.example.ui.theme.DeepSpace
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidBlack
import com.example.viewmodel.SeenuViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainAssistantScreen(
    viewModel: SeenuViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.assistantState.collectAsState()
    val speechText by viewModel.lastAssistantSpeech.collectAsState()
    val personality by viewModel.personalityMode.collectAsState()
    val isServiceRunning by viewModel.isBackgroundServiceActive.collectAsState()

    var textInput by remember { mutableStateOf("") }
    var showPermissionsCard by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(VoidBlack)
            .padding(horizontal = 20.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Status Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SEENU AI",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = NeonCyan,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(NeonPurple.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = personality.displayName,
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonPurple,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                Text(
                    text = "Zero-Touch Sassy Android Voice Assistant",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }

            // Background Service Toggle Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isServiceRunning) NeonEmerald.copy(alpha = 0.2f) else SurfaceElevated)
                    .border(
                        1.dp,
                        if (isServiceRunning) NeonEmerald else SurfaceBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { viewModel.toggleBackgroundService() }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("toggle_background_service"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = if (isServiceRunning) NeonEmerald else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isServiceRunning) "BG Active" else "Wake Service",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isServiceRunning) NeonEmerald else TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // State Indicator Badge
        val (stateText, stateColor) = when (state) {
            AssistantState.IDLE -> Pair("SEENU IS IDLE • TAP ORB", NeonCyan)
            AssistantState.LISTENING -> Pair("LISTENING TO YOU...", NeonCyan)
            AssistantState.THINKING -> Pair("CONJURING SASS...", NeonPurple)
            AssistantState.SPEAKING -> Pair("SEENU IS SPEAKING", NeonPink)
            AssistantState.ERROR -> Pair("SYSTEM GLITCH", NeonRed)
        }

        Box(
            modifier = Modifier
                .background(stateColor.copy(alpha = 0.15f), CircleShape)
                .border(1.dp, stateColor.copy(alpha = 0.6f), CircleShape)
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(stateColor, CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stateText,
                    style = MaterialTheme.typography.labelSmall,
                    color = stateColor,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Central Animated Seenu Orb
        SeenuOrb(
            state = state,
            sizeDp = 220.dp,
            onClick = { viewModel.onOrbClick() }
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Real-time Subtitle / Voice Speech Bubble
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("seenu_speech_card"),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = null,
                            tint = NeonPink,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SEENU SAYS",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonPink,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    if (state == AssistantState.SPEAKING) {
                        Text(
                            text = "Tap orb to stop",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "\"$speechText\"",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 22.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Sassy Command Chips
        Text(
            text = "QUICK COMMANDS & SASS",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted,
            letterSpacing = 1.sp,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val chips = listOf(
                "Roast me!" to Icons.Default.AutoAwesome,
                "Open YouTube" to null,
                "Open WhatsApp" to null,
                "Who are you?" to null,
                "Call Boss" to null,
                "Check my vibe" to null
            )
            for ((label, icon) in chips) {
                SuggestionChip(
                    onClick = { viewModel.triggerQuickAction(label) },
                    label = { Text(label, color = TextPrimary, fontSize = 12.sp) },
                    icon = if (icon != null) {
                        { Icon(icon, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp)) }
                    } else null,
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = SurfaceElevated
                    ),
                    border = SuggestionChipDefaults.suggestionChipBorder(
                        enabled = true,
                        borderColor = SurfaceBorder
                    ),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Permissions banner toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceDark)
                .clickable { showPermissionsCard = !showPermissionsCard }
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (showPermissionsCard) "Hide Permissions Setup" else "View Permissions & Security Setup",
                style = MaterialTheme.typography.labelMedium,
                color = NeonCyan,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = if (showPermissionsCard) "▲" else "▼",
                color = NeonCyan
            )
        }

        AnimatedVisibility(visible = showPermissionsCard) {
            Column {
                Spacer(modifier = Modifier.height(12.dp))
                PermissionsOnboardingCard(
                    onPermissionsUpdated = { viewModel.runDiagnostics() }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Text Fallback Input Bar (Guideline F: usable text fallback if voice unavailable)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceElevated, RoundedCornerShape(16.dp))
                .border(1.dp, SurfaceBorder, RoundedCornerShape(16.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Speak or type to Seenu...", color = TextMuted, fontSize = 13.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("assistant_text_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true
            )

            IconButton(
                onClick = {
                    if (textInput.isNotBlank()) {
                        val toSend = textInput
                        textInput = ""
                        viewModel.submitPrompt(toSend)
                    }
                },
                modifier = Modifier
                    .size(40.dp)
                    .background(NeonCyan, CircleShape)
                    .testTag("send_prompt_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send message",
                    tint = VoidBlack,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
