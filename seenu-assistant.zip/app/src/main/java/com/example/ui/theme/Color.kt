package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Futuristic Cyber Palette
val VoidBlack = Color(0xFF07090E)
val DeepSpace = Color(0xFF0D111A)
val SurfaceDark = Color(0xFF131A29)
val SurfaceElevated = Color(0xFF1B2438)
val SurfaceBorder = Color(0xFF26334D)

// Neon Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDark = Color(0xFF00A3AD)
val NeonPurple = Color(0xFFA855F7)
val NeonPink = Color(0xFFEC4899)
val NeonAmber = Color(0xFFF59E0B)
val NeonEmerald = Color(0xFF10B981)
val NeonRed = Color(0xFFEF4444)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Core M3 mapping
val PrimaryDark = NeonCyan
val SecondaryDark = NeonPurple
val TertiaryDark = NeonPink
