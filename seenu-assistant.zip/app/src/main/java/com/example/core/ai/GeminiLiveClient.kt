package com.example.core.ai

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.core.model.PersonalityMode
import com.example.core.personality.SeenuPersonaEngine
import com.example.core.tools.ToolExecutionEngine
import com.example.core.tools.ToolResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class GeminiResponse {
    data class Text(val content: String, val latencyMs: Long) : GeminiResponse()
    data class ToolCall(val toolName: String, val result: ToolResult, val verbalReply: String, val latencyMs: Long) : GeminiResponse()
    data class Error(val message: String, val isApiKeyMissing: Boolean = false) : GeminiResponse()
}

class GeminiLiveClient(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val conversationHistory = mutableListOf<JSONObject>()
    private val modelName = "gemini-3.5-flash"

    val isApiKeyConfigured: Boolean
        get() {
            val key = BuildConfig.GEMINI_API_KEY
            return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
        }

    suspend fun sendMessage(
        userPrompt: String,
        personalityMode: PersonalityMode = PersonalityMode.SASSY
    ): GeminiResponse = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val startTime = System.currentTimeMillis()

        // Check if API key is valid or missing
        if (!isApiKeyConfigured) {
            val offlineResponse = handleOfflineOrFallback(userPrompt, personalityMode)
            return@withContext offlineResponse
        }

        try {
            val requestBodyJson = buildRequestBody(userPrompt, personalityMode)
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBodyJson.toString().toRequestBody(mediaType)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val latencyMs = System.currentTimeMillis() - startTime
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e("GeminiLiveClient", "HTTP ${response.code}: $responseBody")
                return@withContext GeminiResponse.Error(
                    "Seenu's link to the cloud glitched (HTTP ${response.code}). Falling back to local wit!"
                )
            }

            parseGeminiResponse(responseBody, latencyMs, personalityMode)
        } catch (e: Exception) {
            Log.e("GeminiLiveClient", "Error communicating with Gemini", e)
            val fallback = handleOfflineOrFallback(userPrompt, personalityMode)
            fallback
        }
    }

    private fun buildRequestBody(userPrompt: String, personalityMode: PersonalityMode): JSONObject {
        val root = JSONObject()

        // System Instruction
        val systemInstruction = JSONObject().apply {
            val parts = JSONArray().apply {
                put(JSONObject().apply {
                    put("text", SeenuPersonaEngine.getSystemPrompt(personalityMode))
                })
            }
            put("parts", parts)
        }
        root.put("systemInstruction", systemInstruction)

        // Contents (conversation history + latest prompt)
        val contents = JSONArray()
        for (item in conversationHistory.takeLast(6)) {
            contents.put(item)
        }

        val userContent = JSONObject().apply {
            put("role", "user")
            val parts = JSONArray().apply {
                put(JSONObject().apply {
                    put("text", userPrompt)
                })
            }
            put("parts", parts)
        }
        contents.put(userContent)
        root.put("contents", contents)

        // Tools / Function declarations
        val toolsArray = JSONArray().apply {
            val toolsObject = JSONObject().apply {
                val functionDeclarations = JSONArray().apply {
                    // Tool 1: openApp
                    put(JSONObject().apply {
                        put("name", "openApp")
                        put("description", "Launch an installed Android app like YouTube, WhatsApp, Instagram, Chrome, Calculator")
                        put("parameters", JSONObject().apply {
                            put("type", "OBJECT")
                            put("properties", JSONObject().apply {
                                put("packageName", JSONObject().apply {
                                    put("type", "STRING")
                                    put("description", "The package name or common app name (e.g. 'youtube', 'whatsapp', 'instagram')")
                                })
                            })
                            put("required", JSONArray().apply { put("packageName") })
                        })
                    })

                    // Tool 2: searchAndCallContact
                    put(JSONObject().apply {
                        put("name", "searchAndCallContact")
                        put("description", "Query Android contacts and initiate a phone call to a contact by name")
                        put("parameters", JSONObject().apply {
                            put("type", "OBJECT")
                            put("properties", JSONObject().apply {
                                put("contactName", JSONObject().apply {
                                    put("type", "STRING")
                                    put("description", "The name of the person to call")
                                })
                            })
                            put("required", JSONArray().apply { put("contactName") })
                        })
                    })

                    // Tool 3: sendWhatsAppMessage
                    put(JSONObject().apply {
                        put("name", "sendWhatsAppMessage")
                        put("description", "Send or draft a WhatsApp message to a contact or phone number")
                        put("parameters", JSONObject().apply {
                            put("type", "OBJECT")
                            put("properties", JSONObject().apply {
                                put("contactName", JSONObject().apply {
                                    put("type", "STRING")
                                    put("description", "The contact name or phone number")
                                })
                                put("message", JSONObject().apply {
                                    put("type", "STRING")
                                    put("description", "The message text to send")
                                })
                            })
                            put("required", JSONArray().apply {
                                put("contactName")
                                put("message")
                            })
                        })
                    })

                    // Tool 4: sendGmail
                    put(JSONObject().apply {
                        put("name", "sendGmail")
                        put("description", "Draft and prepare an email in Gmail or default mail app")
                        put("parameters", JSONObject().apply {
                            put("type", "OBJECT")
                            put("properties", JSONObject().apply {
                                put("recipientEmail", JSONObject().apply {
                                    put("type", "STRING")
                                    put("description", "The recipient email address")
                                })
                                put("subject", JSONObject().apply {
                                    put("type", "STRING")
                                    put("description", "The email subject line")
                                })
                                put("body", JSONObject().apply {
                                    put("type", "STRING")
                                    put("description", "The email body text")
                                })
                            })
                            put("required", JSONArray().apply {
                                put("recipientEmail")
                                put("subject")
                                put("body")
                            })
                        })
                    })
                }
                put("functionDeclarations", functionDeclarations)
            }
            put(toolsObject)
        }
        root.put("tools", toolsArray)

        // Generation Config
        val genConfig = JSONObject().apply {
            put("temperature", 0.7)
            put("topP", 0.95)
        }
        root.put("generationConfig", genConfig)

        return root
    }

    private fun parseGeminiResponse(
        jsonString: String,
        latencyMs: Long,
        personalityMode: PersonalityMode
    ): GeminiResponse {
        val root = JSONObject(jsonString)
        val candidates = root.optJSONArray("candidates") ?: return GeminiResponse.Error("No candidates returned from Gemini.")
        val firstCandidate = candidates.optJSONObject(0) ?: return GeminiResponse.Error("Empty candidate response.")
        val content = firstCandidate.optJSONObject("content") ?: return GeminiResponse.Error("Empty content.")
        val parts = content.optJSONArray("parts") ?: return GeminiResponse.Error("No parts returned.")

        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue

            // Check for Function Call
            if (part.has("functionCall")) {
                val functionCall = part.getJSONObject("functionCall")
                val toolName = functionCall.getString("name")
                val args = functionCall.optJSONObject("args") ?: JSONObject()

                val result = executeTool(toolName, args)
                val sassyReply = when (result) {
                    is ToolResult.Success -> "${result.message} Anything else I can charm you with?"
                    is ToolResult.PermissionRequired -> result.message
                    is ToolResult.Error -> "Oof, boss: ${result.message}"
                }
                return GeminiResponse.ToolCall(toolName, result, sassyReply, latencyMs)
            }

            // Standard Text
            if (part.has("text")) {
                val replyText = part.getString("text").trim()
                return GeminiResponse.Text(replyText, latencyMs)
            }
        }

        return GeminiResponse.Text(SeenuPersonaEngine.getRandomGreeting(), latencyMs)
    }

    private fun executeTool(toolName: String, args: JSONObject): ToolResult {
        return when (toolName) {
            "openApp" -> {
                val packageName = args.optString("packageName", "youtube")
                ToolExecutionEngine.openApp(context, packageName)
            }
            "searchAndCallContact" -> {
                val contactName = args.optString("contactName", "")
                ToolExecutionEngine.searchAndCallContact(context, contactName)
            }
            "sendWhatsAppMessage" -> {
                val contact = args.optString("contactName", "")
                val message = args.optString("message", "")
                ToolExecutionEngine.sendWhatsAppMessage(context, contact, message)
            }
            "sendGmail" -> {
                val email = args.optString("recipientEmail", "")
                val subject = args.optString("subject", "")
                val body = args.optString("body", "")
                ToolExecutionEngine.sendGmail(context, email, subject, body)
            }
            else -> ToolResult.Error(toolName, "Unknown tool: $toolName")
        }
    }

    private fun handleOfflineOrFallback(prompt: String, mode: PersonalityMode): GeminiResponse {
        val lower = prompt.lowercase()
        val latency = 80L

        // Check if user is asking to open an app offline
        if (lower.contains("open youtube") || lower.contains("launch youtube")) {
            val res = ToolExecutionEngine.openApp(context, "youtube")
            return GeminiResponse.ToolCall("openApp", res, "Opening YouTube for you right now, darling!", latency)
        }
        if (lower.contains("open whatsapp") || lower.contains("launch whatsapp")) {
            val res = ToolExecutionEngine.openApp(context, "whatsapp")
            return GeminiResponse.ToolCall("openApp", res, "WhatsApp launched! Who are we gossiping with?", latency)
        }
        if (lower.contains("open chrome") || lower.contains("launch browser")) {
            val res = ToolExecutionEngine.openApp(context, "chrome")
            return GeminiResponse.ToolCall("openApp", res, "Launching Chrome! Don't get lost on the web.", latency)
        }
        if (lower.contains("call ")) {
            val target = prompt.substringAfter("call ").trim().take(30)
            val res = ToolExecutionEngine.searchAndCallContact(context, target)
            return GeminiResponse.ToolCall("searchAndCallContact", res, res.let {
                if (it is ToolResult.Success) it.message else "Checking contact details for $target!"
            }, latency)
        }
        if (lower.contains("roast me") || lower.contains("roast")) {
            return GeminiResponse.Text(SeenuPersonaEngine.getRandomRoast(), latency)
        }
        if (lower.contains("who are you") || lower.contains("your name")) {
            return GeminiResponse.Text(
                "I am Seenu! Your young, witty, and unapologetically sassy personal AI assistant. Don't worry, you're in good hands.",
                latency
            )
        }

        // Default charming fallback
        val defaultReplies = listOf(
            "Honey, I'm working with my offline quick-sass right now. Add your GEMINI_API_KEY in the Secrets panel to unleash my full cosmic brainpower!",
            "I heard you loud and clear! Seenu is here. Connect your Gemini API key for uncapped conversational genius.",
            "Always at your service, boss. Even in offline mode, I'm sharper than your average assistant!"
        )
        return GeminiResponse.Text(defaultReplies.random(), latency)
    }

    suspend fun pingTest(): Pair<Boolean, Long> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (!isApiKeyConfigured) return@withContext Pair(false, 0L)

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName?key=$apiKey"
            val request = Request.Builder().url(url).get().build()
            val response = client.newCall(request).execute()
            val latency = System.currentTimeMillis() - startTime
            Pair(response.isSuccessful, latency)
        } catch (e: Exception) {
            Pair(false, 0L)
        }
    }
}
