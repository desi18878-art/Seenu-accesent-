package com.example.core.tools

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import java.net.URLEncoder

sealed class ToolResult {
    data class Success(val toolName: String, val message: String, val details: String? = null) : ToolResult()
    data class PermissionRequired(val toolName: String, val missingPermission: String, val message: String) : ToolResult()
    data class Error(val toolName: String, val message: String) : ToolResult()
}

object ToolExecutionEngine {

    // Common app aliases mapping
    private val APP_PACKAGE_MAP = mapOf(
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "chrome" to "com.android.chrome",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "calculator" to "com.google.android.calculator",
        "camera" to "com.android.camera2",
        "settings" to "com.android.settings",
        "spotify" to "com.spotify.music",
        "telegram" to "org.telegram.messenger",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android"
    )

    fun openApp(context: Context, targetPackageOrName: String): ToolResult {
        val cleanName = targetPackageOrName.trim().lowercase()
        val packageName = APP_PACKAGE_MAP[cleanName] ?: targetPackageOrName.trim()

        val packageManager = context.packageManager
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)

        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(launchIntent)
                ToolResult.Success(
                    toolName = "openApp",
                    message = "Opened $cleanName for you, boss!",
                    details = "Package: $packageName"
                )
            } catch (e: Exception) {
                ToolResult.Error(
                    toolName = "openApp",
                    message = "Failed to launch $cleanName: ${e.message}"
                )
            }
        } else {
            // Fallback: search on Play Store or web
            try {
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$cleanName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(marketIntent)
                ToolResult.Success(
                    toolName = "openApp",
                    message = "App '$cleanName' isn't installed, so I opened the Play Store search for it!",
                    details = "Redirected to store search"
                )
            } catch (e: Exception) {
                ToolResult.Error(
                    toolName = "openApp",
                    message = "Couldn't find app '$cleanName' on this device."
                )
            }
        }
    }

    fun searchAndCallContact(context: Context, contactName: String): ToolResult {
        val hasContactsPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasContactsPermission) {
            return ToolResult.PermissionRequired(
                toolName = "searchAndCallContact",
                missingPermission = Manifest.permission.READ_CONTACTS,
                message = "I need permission to read your contacts first, darling! Tap allow so I can find $contactName."
            )
        }

        // Query contacts provider
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$contactName%")

        var foundNumber: String? = null
        var foundName: String? = null

        try {
            resolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (nameIndex >= 0 && numberIndex >= 0) {
                        foundName = cursor.getString(nameIndex)
                        foundNumber = cursor.getString(numberIndex)
                    }
                }
            }
        } catch (e: Exception) {
            return ToolResult.Error(
                toolName = "searchAndCallContact",
                message = "Error searching contacts: ${e.message}"
            )
        }

        if (foundNumber == null) {
            return ToolResult.Error(
                toolName = "searchAndCallContact",
                message = "Couldn't find anyone named '$contactName' in your contacts. Double-check the spelling!"
            )
        }

        val hasCallPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val intent = if (hasCallPermission) {
            Intent(Intent.ACTION_CALL, Uri.parse("tel:$foundNumber")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } else {
            // Safe fallback: open dialer with pre-filled number without needing CALL_PHONE permission!
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$foundNumber")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }

        return try {
            context.startActivity(intent)
            ToolResult.Success(
                toolName = "searchAndCallContact",
                message = if (hasCallPermission) "Calling $foundName now!" else "Opening dialer for $foundName!",
                details = "Contact: $foundName ($foundNumber)"
            )
        } catch (e: Exception) {
            ToolResult.Error(
                toolName = "searchAndCallContact",
                message = "Unable to start call: ${e.message}"
            )
        }
    }

    fun sendWhatsAppMessage(context: Context, contactNameOrNumber: String, message: String): ToolResult {
        val encodedMessage = try {
            URLEncoder.encode(message, "UTF-8")
        } catch (e: Exception) {
            message
        }

        // Check if contactNameOrNumber is pure digits or name
        val digitsOnly = contactNameOrNumber.filter { it.isDigit() }
        val targetUri = if (digitsOnly.length >= 7) {
            Uri.parse("https://api.whatsapp.com/send?phone=$digitsOnly&text=$encodedMessage")
        } else {
            // General WhatsApp send intent with text
            Uri.parse("https://api.whatsapp.com/send?text=$encodedMessage")
        }

        val intent = Intent(Intent.ACTION_VIEW, targetUri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ToolResult.Success(
                toolName = "sendWhatsAppMessage",
                message = "Drafted WhatsApp message for $contactNameOrNumber! Check WhatsApp to send it.",
                details = "Target: $contactNameOrNumber, Text: \"$message\""
            )
        } catch (e: Exception) {
            // WhatsApp not installed, try general share intent
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(Intent.createChooser(shareIntent, "Send via").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
                ToolResult.Success(
                    toolName = "sendWhatsAppMessage",
                    message = "WhatsApp isn't installed, so I opened the share sheet for your message!",
                    details = "Shared: \"$message\""
                )
            } catch (ex: Exception) {
                ToolResult.Error(
                    toolName = "sendWhatsAppMessage",
                    message = "Failed to launch messaging app: ${ex.message}"
                )
            }
        }
    }

    fun sendGmail(context: Context, recipientEmail: String, subject: String, body: String): ToolResult {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$recipientEmail")
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ToolResult.Success(
                toolName = "sendGmail",
                message = "Drafted email to $recipientEmail! Review and tap send.",
                details = "Subject: $subject"
            )
        } catch (e: Exception) {
            ToolResult.Error(
                toolName = "sendGmail",
                message = "Couldn't find an email app to send to $recipientEmail: ${e.message}"
            )
        }
    }
}
