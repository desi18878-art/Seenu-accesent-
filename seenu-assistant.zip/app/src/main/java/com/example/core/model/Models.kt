package com.example.core.model

enum class AssistantState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

enum class PersonalityMode(val displayName: String, val tagline: String) {
    SASSY("Sassy & Confident", "Young, teasing, sharp wit & playful attitude"),
    SAVAGE("Extra Savage", "Maximum roast potential with zero filter"),
    FLIRTY_BOSS("Playful Partner", "Warm, flirty, charming, and fiercely protective"),
    SMART_WIT("Witty Genius", "Brainy, sarcastic, clever observations")
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isToolExecution: Boolean = false,
    val toolName: String? = null,
    val toolDetails: String? = null
)

enum class DiagnosticStatus {
    PASS,
    WARN,
    FAIL,
    RUNNING,
    PENDING
}

data class DiagnosticItem(
    val id: String,
    val title: String,
    val description: String,
    val status: DiagnosticStatus = DiagnosticStatus.PENDING,
    val latencyMs: Long? = null,
    val details: String = ""
)

data class PermissionItem(
    val permission: String,
    val displayName: String,
    val description: String,
    val isGranted: Boolean,
    val iconName: String
)
