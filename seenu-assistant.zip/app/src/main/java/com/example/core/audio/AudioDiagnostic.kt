package com.example.core.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class MicTestResult(
    val hasPermission: Boolean,
    val canInitializeHardware: Boolean,
    val sampleRate: Int = 16000,
    val detectedAmplitude: Int = 0,
    val message: String
)

object AudioDiagnostic {

    suspend fun runIndependentMicTest(context: Context): MicTestResult = withContext(Dispatchers.IO) {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            return@withContext MicTestResult(
                hasPermission = false,
                canInitializeHardware = false,
                message = "Microphone permission is NOT granted. Grant permission in Android settings."
            )
        }

        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

        if (minBufferSize == AudioRecord.ERROR || minBufferSize == AudioRecord.ERROR_BAD_VALUE) {
            return@withContext MicTestResult(
                hasPermission = true,
                canInitializeHardware = false,
                message = "Device audio hardware reported invalid buffer size for 16kHz PCM."
            )
        }

        var recorder: AudioRecord? = null
        try {
            recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                minBufferSize * 2
            )

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                return@withContext MicTestResult(
                    hasPermission = true,
                    canInitializeHardware = false,
                    message = "AudioRecord could not initialize hardware (another app might be using the mic)."
                )
            }

            recorder.startRecording()
            val buffer = ShortArray(1024)
            val readCount = recorder.read(buffer, 0, buffer.size)

            var maxAmplitude = 0
            if (readCount > 0) {
                for (i in 0 until readCount) {
                    val abs = kotlin.math.abs(buffer[i].toInt())
                    if (abs > maxAmplitude) maxAmplitude = abs
                }
            }

            recorder.stop()
            recorder.release()

            MicTestResult(
                hasPermission = true,
                canInitializeHardware = true,
                sampleRate = sampleRate,
                detectedAmplitude = maxAmplitude,
                message = "Microphone hardware is healthy! Peak amplitude: $maxAmplitude."
            )
        } catch (e: Exception) {
            recorder?.release()
            MicTestResult(
                hasPermission = true,
                canInitializeHardware = false,
                message = "Microphone test failed: ${e.message}"
            )
        }
    }
}
